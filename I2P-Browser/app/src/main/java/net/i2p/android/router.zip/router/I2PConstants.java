package net.i2p.android.router;

public interface I2PConstants {
    String ANDROID_PREF_PREFIX = "i2pandroid.";
}
